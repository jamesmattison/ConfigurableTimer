import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="ConfigurableTimer-0.01-jamesmattison",
    version="0.01",
    author="James Mattison",
    author_email="james@vixal.net",
    description="A configurable alarm, using threading, to execute options after a delay.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/jamesmattison/ConfigurableTimer",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
