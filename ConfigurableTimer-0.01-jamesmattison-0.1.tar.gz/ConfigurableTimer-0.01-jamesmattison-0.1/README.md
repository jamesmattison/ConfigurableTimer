ConfigurableTimer Documentation:
-----------------------------------------
NOTE: THIS IS A WORK IN PROGRESS, DONT TRY TO USE IT TIL I REMOVE THIS LINE
version: .01

class Timer
	L Timer
	L TimerThread
	L TimerTargets
	L TimerError




Timer:
	Timer(alarm_type, fn=<>, testmode=False, **kwargs)
	start(when, message, tn=None, verbose=True)
	status()

TimerThread:
	TimerThread(tinfo)
	alarm_t()
	execute_alarm_target()

TimerTarget:
	TimerTarget(tinfo)
	send_sms(message, to=<>)
	callout(to)
	send_email(to, subject, message)
	play_wav(fn)
**todo: ---> system_out(to_execute)

--------------------------------------
TODO:
	toadd:
	------
		-TimerLog
		-TimerHopper
		-TimerDaemon

1. write daemon (systemd sservice file)
2. write oneshot script
3. figure out hopper (subprocess? multiprocessing?)
4. try packing it up, why not

tinfo: tinfo = {
        "tid": Timer.i,
        "name": self.tn,
        "init_time": self.init_time,
        "alarm_time": self.at,
        "testmode": self.testmode,
        "todo": self.todo,
        "message": self.msg,
        "verbose": self.verbose
        }
